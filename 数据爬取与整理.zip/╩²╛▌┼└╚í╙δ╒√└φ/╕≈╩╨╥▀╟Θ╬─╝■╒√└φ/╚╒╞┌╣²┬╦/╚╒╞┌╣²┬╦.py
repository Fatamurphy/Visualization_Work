# -*- coding: utf-8 -*-
"""
Created on Sun Mar 22 10:44:13 2020

@author: Administrator
"""
import csv

cityName = ['武汉','孝感','鄂州','随州','荆门','荆州','仙桃','黄石','宜昌','襄阳','十堰','天门','潜江','黄冈','咸宁','恩施州','神农架林区']

for city in cityName:
    print(city)
    fileName = '..\\' + city + '疫情时间信息.csv'
    csv_file=open(fileName,'r',newline='',encoding='utf-8')
    reader=csv.reader(csv_file)
    
    name = city + '疫情每日信息.csv'
    new_file = open(name,'w',newline='',encoding='utf-8')
    writer = csv.writer(new_file)
    
    temp = ''
    for row in reader:
        #取出日期，每天只保留一个数据
        if temp != row[0][:10]:
            temp = row[0][:10]
            row[0] = temp
            print(row)
            writer.writerow(row)
            
    csv_file.close()
    new_file.close()

print('日期过滤完成')