# -*- coding: utf-8 -*-
"""
Created on Sat Mar 21 12:12:07 2020

@author: Administrator
"""

import xlrd
import csv

file ='..\湖北省各市疫情时间信息.xlsx'
workbook =xlrd.open_workbook(file)
#选择第一张sheet 
sheet =workbook.sheet_by_index(0)    


#根据不同的市建立不同名称的excel文件
for row in range(1, 18): 
    #取出1-17行城市名     
    cityName = sheet.row(row)[0].value
    #print(cityName)
    
    #建立新的文件
    fileName = cityName+'疫情时间信息.csv'
    csv_file = open(fileName,'w',newline='',encoding='utf-8')
    
    title = ['时间','现存确诊','累计确诊','治愈人数','死亡人数']
    writer = csv.writer(csv_file)
    writer.writerow(title)
    csv_file.close()
  
#遍历所有行分类写入新的城市文件
for row in range(1, sheet.nrows):
    cityName = sheet.row(row)[0].value
    
    #原始数据中统计了监狱系统和待明确地区
    if cityName != '监狱系统' and cityName != '待明确地区' and cityName != '未知地区':
        cityFile = cityName+'疫情时间信息.csv'
        print(cityFile)
        
        csv_file = open(cityFile,'a',newline='',encoding='utf-8')
        writer = csv.writer(csv_file)
        
        #将每一格数据存入列表，写入打开的csv文件中
        list = []
        for col in range(1, sheet.ncols):
            #取出每一格的值存入list
            data = sheet.row(row)[col].value
            list.append(data)
            #将list追加入文件
        writer.writerow(list)
        print(list,'\n')
        csv_file.close()