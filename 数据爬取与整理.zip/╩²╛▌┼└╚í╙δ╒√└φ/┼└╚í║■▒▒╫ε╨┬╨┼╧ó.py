# -*- coding: utf-8 -*-
"""
Created on Wed Mar 18 15:45:54 2020

@author: Administrator
"""

import requests
import openpyxl
import csv
import time

wb=openpyxl.Workbook() 
sheet=wb.active
sheet.title='湖北省各市疫情最新消息'

sheet['A1'] = '城市'
sheet['B1'] = '现存确诊'
sheet['C1'] = '累计确诊'
sheet['D1'] = '疑似病例'
sheet['E1'] = '治愈人数'
sheet['F1'] = '死亡人数'


headers={'user-agent':'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36'}
url = 'https://lab.isaaclin.cn/nCoV/api/area'
params1 = {'latest':'1', 
           'province':'湖北省'
           }

res = requests.get(url, headers=headers, params=params1)
print('湖北省疫情最新消息：')
print(res)

res = res.json()
res = res['results']
res = res[0]

#湖北总信息
provinceName = res['provinceName']
updateTime = str(res['updateTime'])
#时间戳转换
updateTime = int(updateTime[:10])
timeArray = time.localtime(updateTime)
updateTime = time.strftime("%Y/%m/%d %H:%M:%S", timeArray)

currentConfirmedCount = res['currentConfirmedCount']
confirmedCount = res['confirmedCount']
suspectedCount = res['suspectedCount']
curedCount = res['curedCount']
deadCount = res['deadCount']

file = open('湖北省疫情最新消息.txt', 'w', encoding = 'utf-8')
csv_file = open('湖北省疫情最新消息.csv','w',newline='',encoding='utf-8')
writer = csv.writer(csv_file)

print("省份：",provinceName)
file.write("省份："+provinceName+"\n")
writer.writerow(["省份",provinceName])
print("更新时间：",updateTime)
file.write("更新时间："+str(updateTime)+"\n")
writer.writerow(["更新时间",updateTime])
print("现存确诊：",currentConfirmedCount)
file.write("现存确诊："+str(currentConfirmedCount)+"\n")
writer.writerow(["现存确诊",currentConfirmedCount])
print("累计确诊：",confirmedCount)
file.write("累计确诊："+str(confirmedCount)+"\n")
writer.writerow(["累计确诊",confirmedCount])
print("疑似病例：",suspectedCount)
file.write("疑似病例："+str(suspectedCount)+"\n")
writer.writerow(["疑似病例",suspectedCount])
print("治愈人数：",curedCount)
file.write("治愈人数："+str(curedCount)+"\n")
writer.writerow(["治愈人数",curedCount])
print("死亡人数：",deadCount)
file.write("死亡人数："+str(deadCount)+"\n")
writer.writerow(["死亡人数",deadCount])

csv_file.close()
file.close()

#各个城市信息
print('')
cities = res['cities']

for city in cities:
    cityName = city['cityName']
    print("城市：",cityName)
    cityCurrentConfirmedCount = city['currentConfirmedCount']
    print("现存确诊：",cityCurrentConfirmedCount)
    cityConfirmedCount = city['confirmedCount']
    print("累计确诊：",cityConfirmedCount)
    citySuspectedCount = city['suspectedCount']
    print("疑似病例：",citySuspectedCount)
    cityCuredCount = city['curedCount']
    print("治愈人数：",cityCuredCount)
    cityDeadCount = city['deadCount']
    print("死亡人数：",cityDeadCount)
    print('')
    sheet.append([cityName, cityCurrentConfirmedCount, cityConfirmedCount, citySuspectedCount, cityCuredCount, cityDeadCount])
    
wb.save('湖北省各市疫情最新消息.xlsx')