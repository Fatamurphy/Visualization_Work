# -*- coding: utf-8 -*-
"""
Created on Wed Mar 18 17:01:55 2020

@author: Administrator
"""
import json
import openpyxl
import time

wb=openpyxl.Workbook() 
sheet=wb.active
sheet.title='疫情历史消息'

sheet['A1'] = '城市'
sheet['B1'] = '时间'
sheet['C1'] = '现存确诊'
sheet['D1'] = '累计确诊'
sheet['E1'] = '治愈人数'
sheet['F1'] = '死亡人数'

with open('DXYArea-TimeSeries.json', 'r', encoding='utf8') as f:
    series = json.load(f)
    print(len(series))
    print(type(series))

for data in series:
    if data['provinceName'] == '湖北省':
        updateTime = str(data['updateTime'])
        updateTime = int(updateTime[:10])
        timeArray = time.localtime(updateTime)
        updateTime = time.strftime("%Y/%m/%d %H:%M:%S", timeArray)
        
        cities = data['cities']
        
        if cities:
            print(updateTime)
            print(len(cities))
            #print(cities)
            for city in cities:
                print(city)
                current = city['confirmedCount'] - city['curedCount'] - city['deadCount']
                sheet.append([city['cityName'], updateTime, current, city['confirmedCount'], city['curedCount'], city['deadCount']])
                
        print()
        
wb.save('湖北省各市疫情时间信息.xlsx')